% ----------------------------------------------------------------------------------------- %
%      AAA      MM       MM      AAA      LL        GGGGGGGGGGG      AAA      MM       MM   %
%     AA AA     MMM     MMM     AA AA     LL        GGG     GGG     AA AA     MMM     MMM   %
%     AA AA     MMMM   MMMM     AA AA     LL        GG       GG     AA AA     MMMM   MMMM   %
%    AA   AA    MM MM MM MM    AA   AA    LL        GGG     GGG    AA   AA    MM MM MM MM   %
%   AAAAAAAAA   MM  MMM  MM   AAAAAAAAA   LL        GGGGGGGGGGG   AAAAAAAAA   MM  MMM  MM   %
%   AA     AA   MM       MM   AA     AA   LL                 GG   AA     AA   MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL           GG  AA       AA  MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL  GGGGGGGGGGG  AA       AA  MM       MM   %
% ----------------------------------------------------------------------------------------- %

%% Define fields of AMALGAMPar
AMALGAMPar.N = 100;                     % Define population size
AMALGAMPar.T = 250;                     % How many generations?
AMALGAMPar.m = 3;                       % How many objective functions?

%% Define fields of Par_info
Par_info.initial = 'latin';             % Latin hypercube sampling
Par_info.boundhandling = 'reflect';     % Explicit boundary handling

%% Define name of function (.m file) for posterior exploration
Func_name = 'AMALGAM_BMA';

%% Load data from Vrugt and Robinson, WRR, 43, W01411, doi:10.1029/2005WR004838, 2007
data = load('pressure.txt');            % 48-h sea level pressure forecasts (K) UW ensemble 
idx = find(data(:,1) == 2000 & data(:,2) == 4 & data(:,3) == 16); start_idx = idx(1);
idx = find(data(:,1) == 2000 & data(:,2) == 6 & data(:,3) == 9); end_idx = idx(end);
T_idx = [ start_idx : end_idx ];

%% Define the second input argument of BMA_multcalc
func_in.D = data(T_idx,5:9);            % Store ensemble forecasts
func_in.Y = data(T_idx,4);              % Store verifying observations
func_in.PDF = 'normal';                 % Store name of forecast distribution ('normal'/'gamma')
func_in.VAR = '2';                      % Store variance option ('1'/'2'/'3'/'4')

%% Setup the BMA model (apply linear bias correction)
[AMALGAMPar,Par_info] = setup_BMA(AMALGAMPar,Par_info,func_in);

%% Define structure options
options.ranking = 'C';                  % Use Pareto ranking in C
options.print = 'yes';                  % Print output to screen
options.parallel = 'no';                % Multicore evaluation offspring
options.modout = 'yes';                 % Return simulation of BMA model
%options.save = 'yes';                  % save for restart run
%options.restart = 'yes';               % restart run 

%% Run the AMALGAM code and obtain non-dominated solution set
[X,F,output,Z,Y_sim] = AMALGAM(AMALGAMPar,Func_name,Par_info,options,func_in);