function [ F , G_dot ] = AMALGAM_BMA ( x , func_in )
% This function calculates the RMSE, IS, and CRPS of the BMA mixture distribution
% Reference: J.A. Vrugt, M.P. Clark, C.G.H. Diks, Q. Duan, and B. A. Robinson (2006), 
%   Multi-objective calibration of forecast ensembles using Bayesian model averaging, 
%   Geophysical Research Letters, 33, L19817, 2006

if nargin < 2
    error('AMALGAM_BMA:TooFewInputs','Requires at least two input arguments.');
end

[D,Y,PDF,VAR] = v2struct(func_in,{'Fieldnames','D','Y','PDF','VAR'}); % Unpack fields func_in

[n,K] = size(D);            % Ensemble size (number forecasts, number models)
w = x(1:K);                 % Unpack weights from (d x 1) vector, x with parameter values

switch VAR % VARIANCE OPTION -> (n x K)-matrix "sigma" with standard deviations forecasts
    case {'1'} % 1: common constant variance
        sigma = x(K+1) * ones(n,K);                                    
    case {'2'} % 2: individual constant variance
        sigma = bsxfun(@times,x(K+1:2*K)',ones(n,K));                               
    case {'3'} % 3: common non-constant variance
        c = x(K+1); sigma = c * D;                               
    case {'4'} % 4: individual non-constant variance
        c = x(K+1:2*K)'; sigma = bsxfun(@times,c,D);            
end
sigma = max(sigma,eps);     % each element (n x K)-matrix sigma at least equal to 2.22e-16

switch PDF % CONDITIONAL DISTRIBUTION -> (n x K)-matrices "A" and "B"
    case {'normal'} % Gaussian with mean "D" and standard deviation "sigma"
        A = D; B = sigma; 
    case {'gamma'}  % Gamma with shape "A" and scale "B"  
        mu = abs(D); var = sigma.^2; A = mu.^2./var; B = var./mu;
end
L = pdf(PDF,repmat(Y,1,K),A,B);     % (n x K)-matrix of likelihoods forecasts at Y
lik = L*w + realmin;                % (n x 1)-vector of likelihoods BMA model at Y
G_dot = D*w; res = G_dot - Y;       % (n x 1)-vectors of BMA mean forecast and residuals
G = BMA_rnd(PDF,w,A,B,2);           % Draw randomly two [n x 1]-vectors of BMA forecasts at Y

F(1) = sqrt(1/n*(res'*res));                      % F_{1}: RMSE mean forecast BMA model
F(2) = -mean(log(lik));                           % F_{2}: Ignorance score BMA model
F(3) = mean(abs(G{1}-Y))-.5*mean(abs(G{1}-G{2})); % F_{3}: CRPS score BMA model