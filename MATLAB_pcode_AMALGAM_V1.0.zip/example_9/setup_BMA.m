function [AMALGAMPar,Par_info] = setup_BMA(AMALGAMPar,Par_info,func_in)
% Determines setup of multi-criteria BMA model training

% Define BMA as 'on';
global BMA

% Unpack size of ensemble forecasts
[n,K] = size(func_in.D);

switch func_in.VAR
    
    case '1'    % 1: common constant variance
        AMALGAMPar.d = K + 1; Par_info.max = [ ones(1,K) 2 * std(func_in.Y) ];
    case '2'    % 2: individual constant variance
        AMALGAMPar.d = 2 * K; Par_info.max = [ ones(1,K) 2 * std(func_in.Y)*ones(1,K) ];
    case {'3'}  % 3: common non-constant variance
        AMALGAMPar.d = K + 1; Par_info.max = [ ones(1,K) 2 ];
    case {'4'}  % 4: individual non-constant variance
        AMALGAMPar.d = 2 * K; Par_info.max = [ ones(1,K) 2*ones(1,K) ];
    otherwise
        error('AMALGAM:setup_BMA:Unknown variance option; choose between ''1''/''2''/''3''/''4'' '); 

end        

% Weights must be on simplex - otherwise predictive density is meaningless
Par_info.min = zeros(1,AMALGAMPar.d);

% Define field K of BMA
BMA.K = K;