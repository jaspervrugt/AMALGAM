function [ G ] = BMA_rnd ( PDF , w , A , B , P )
% This function creates sampled trajectories of the BMA forecast distribution
% Reference: J.A. Vrugt, M.P. Clark, C.G.H. Diks, Q. Duan, and B. A. Robinson (2006), 
%   Multi-objective calibration of forecast ensembles using Bayesian model averaging, 
%   Geophysical Research Letters, 33, L19817, 2006

if nargin < 5,
    error('AMALGAM ERROR: BMA_rnd:TooFewInputs','Requires at least five input arguments.');
end

[n,K] = size(A);    % How many forecasts and ensemble members
          
for p = 1:P,        % Draw N trajectories from BMA forecast distribution
    id = randsample(1:K,n,'true',w);            % Select n times from 1:K using weights w
    for k = 1:K,                        
        T = find(id == k);                      % kth component used for indices of T
        G{p}(T,1) = random(PDF,A(T,k),B(T,k));  % Draw sample from kth mixture component
    end
end