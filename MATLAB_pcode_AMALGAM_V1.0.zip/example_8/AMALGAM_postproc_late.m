

load AMALGAM.mat

plotting = AMALGAM_end(AMALGAMPar,options);                                     % Close workers/directories, if appropriate
Z = Z(1:tel*AMALGAMPar.N,1:AMALGAMPar.d+AMALGAMPar.m);                          % Remove NaNs from archive Z
AMALGAM_postproc(AMALGAMPar,Par_info,options,X,F,output,Fpar,plotting,Y_X,Z);   % Now post-process results of AMALGAM