function F = AMALGAM_ZDT1 ( x , d )
% ZDT1 - test function
% Reference: E. Zitzler, K. Deb, and L. Thiele, Comparison of multiobjective 
%   evolutionary algorithms: Empirical results, Evolutionary Computation, 8 (2), 
%   183-195, 2000

f = x(1);                       % f
g = 1 + 9/(d-1)*sum(x(2:d));    % g
h = 1 - sqrt(f./g);             % h
F(1) = f; F(2) = g.*h;          % Return objective functions