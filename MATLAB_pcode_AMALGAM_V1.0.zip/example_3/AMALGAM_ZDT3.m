function Y = AMALGAM_ZDT3 ( x , d )
% ZDT3 - test function
% Reference: E. Zitzler, K. Deb, and L. Thiele, Comparison of multiobjective 
%   evolutionary algorithms: Empirical results, Evolutionary Computation, 8 (2), 
%   183-195, 2000

f = x(1);                                   % f                     
g = 1 + 9/(d-1)*sum(x(2:d));                % g
h = 1 - sqrt(f./g) - (f./g).*sin(10*pi*f);  % h
Y(1) = f; Y(2) = g.*h;                      % Return objective functions