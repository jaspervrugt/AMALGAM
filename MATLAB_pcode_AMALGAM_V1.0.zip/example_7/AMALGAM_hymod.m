function [ F , Y_sim ] = AMALGAM_hymod ( x , func_in )
% ----------------------------------------------------------------------- %
% This function executes the HYMOD conceptual watershed model and returns % 
%   a pair of objective function values                                   %
%                                                                         %
% Reference: J.A. Vrugt, H.V. Gupta, L.A. Bastidas, W. Bouten, and        %
%   S. Sorooshian, Effective and efficient algorithm for multiobjective   % 
%   optimization of hydrologic models, Water Resources Research, 39(8),   % 
%   1214, doi:10.1029/2002WR001746, 2003                                  %
%                                                                         %
% ----------------------------------------------------------------------- %

% Extract the parameters
cmax = x(1); bexp = x(2); alpha = x(3); Rs = x(4); Rq = x(5);

% Extract various input data
[T_max,Y_obs,PET,R,idx_d,N_d,idx_nd,N_nd] = v2struct(func_in,func_in.fields);

% Set the initial states
x_loss = 0.0;

% Initialize slow tank state
x_slow = 0; % --> works ok if calibration data starts with low discharge

% Initialize state(s) of quick tank(s)
x_quick = zeros(3,1);

% Now loop over the forcing data
for t = 1 : T_max
    
    % Compute excess precipitation and evaporation
    [ER1,ER2,x_loss] = excess(x_loss,cmax,bexp,R(t,1),PET(t,1));
    
    % Calculate total effective rainfall
    ET = ER1 + ER2;
    
    % Now partition ER between quick and slow flow reservoirs
    UQ = alpha * ET; US = (1-alpha) * ET;
    
    % Route slow flow component with single linear reservoir
    [x_slow,QS] = linres(x_slow,US,Rs);
    
    % Route quick flow component with linear reservoirs
    inflow = UQ;
    
    for k = 1 : 3
        % Linear reservoir
        [x_quick(k),outflow] = linres(x_quick(k),inflow,Rq); inflow = outflow;
    end;
    
    % Compute total flow for timestep (in mm/day)
    output(t,1) = (QS + outflow);
    
end;

% Apply burn-in of 65 days
Y_sim = output(65:T_max,1); 

% Calculate the objective function values -- driven part
F(1,1) = sqrt ( sum ( ( Y_sim(idx_d) - Y_obs(idx_d) ).^2)/N_d);
% Calculate the objective function values -- nondriven part
F(2,1) = sqrt ( sum ( ( Y_sim(idx_nd) - Y_obs(idx_nd) ).^2)/N_nd);

% -------------------------------------------------------------------------
function [ER1,ER2,xn] = excess(x_loss,cmax,bexp,Pval,PETval)
% this function calculates excess precipitation and evaporation

xn_prev = x_loss;
ct_prev = cmax*(1-power((1-((bexp+1)*(xn_prev)/cmax)),(1/(bexp+1))));
% Calculate Effective rainfall 1
ER1 = max((Pval-cmax+ct_prev),0.0);
Pval = Pval-ER1;
dummy = min(((ct_prev+Pval)/cmax),1);
xn = (cmax/(bexp+1))*(1-power((1-dummy),(bexp+1)));
% Calculate Effective rainfall 2
ER2 = max(Pval-(xn-xn_prev),0);

% Alternative approach
evap = (1-(((cmax/(bexp+1))-xn)/(cmax/(bexp+1))))*PETval; % actual ET is linearly related to the soil moisture state
xn = max(xn-evap, 0); % update state

%evap = min(xn,PETval);
%xn = xn-evap;

% -------------------------------------------------------------------------

function [x_slow,outflow] = linres(x_slow,inflow,Rs)
% Linear reservoir
x_slow = (1-Rs)*x_slow + (1-Rs)*inflow;
outflow = (Rs/(1-Rs))*x_slow;