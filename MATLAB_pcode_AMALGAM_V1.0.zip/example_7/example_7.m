% ----------------------------------------------------------------------------------------- %
%      AAA      MM       MM      AAA      LL        GGGGGGGGGGG      AAA      MM       MM   %
%     AA AA     MMM     MMM     AA AA     LL        GGG     GGG     AA AA     MMM     MMM   %
%     AA AA     MMMM   MMMM     AA AA     LL        GG       GG     AA AA     MMMM   MMMM   %
%    AA   AA    MM MM MM MM    AA   AA    LL        GGG     GGG    AA   AA    MM MM MM MM   %
%   AAAAAAAAA   MM  MMM  MM   AAAAAAAAA   LL        GGGGGGGGGGG   AAAAAAAAA   MM  MMM  MM   %
%   AA     AA   MM       MM   AA     AA   LL                 GG   AA     AA   MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL           GG  AA       AA  MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL  GGGGGGGGGGG  AA       AA  MM       MM   %
% ----------------------------------------------------------------------------------------- %

%% Define fields of AMALGAMPar
AMALGAMPar.N = 100;                             % Define population size
AMALGAMPar.T = 100;                             % How many generations?
AMALGAMPar.d = 5;                               % How many parameters?
AMALGAMPar.m = 2;                               % How many objective functions?

%% Define fields of Par_info
Par_info.initial = 'latin';                     % Latin hypercube sampling
Par_info.boundhandling = 'reflect';             % Explicit boundary handling
Par_info.min = [1.0 0.10 0.10 0.00 0.10];       % If 'latin', min values
Par_info.max = [500 2.00 0.99 0.10 0.99];       % If 'latin', max values
Par_info.steps = 499*ones(1,AMALGAMPar.d);
%% Define name of function
Func_name = 'AMALGAM_hymod';

%% Define data to be used for multi-criteria model calibration 

% Load daily data from the Leaf River watershed (7/28/1952 - 9/30/1962)
load bound.txt;
% Area of Leaf River in km^2 (required to convert measured discharge in m3/s to mm/day) 
Area = 1944; m3_per_sec_to_mm_per_day = Area * (1000 * 1000 ) / (1000 * 60 * 60 * 24);
% Use two years of data
T_max = 795;
% Extract measured streamflow data in m3/s and convert to mm/day
Y_obs = bound(65:T_max,4)/m3_per_sec_to_mm_per_day;
% Extract potential evapotranspiration data, PET (mm/day)
PET = bound(1:T_max,5);
% Extract precipitation data (mm/day) (take sum of 6-hourly data in mm/day)
R = sum(bound(1:T_max,6:9),2);
% Indexes of data which constitute driven part of hydrograph (fed by rain)
idx_d = find(R(65:end) > 0); N_d = numel(idx_d);
% Indexes of data which make up nondriven part of hydrograph (dry days)
idx_nd = find(R(65:end) == 0); N_nd = numel(idx_nd);
% Now collect necessary data in structure func_in (passed to AMALGAM_hymod)
field_Names = {'fieldnames','T_max','Y_obs','PET','R','idx_d','N_d','idx_nd','N_nd'};
% Now create func_in with fields
func_in = v2struct(T_max,Y_obs,PET,R,idx_d,N_d,idx_nd,N_nd,field_Names); 
% Store field_Names for unpacking in AMALGAM_hymod
func_in.fields = field_Names;

%% Define structure options
options.parallel = 'yes';                       % Multi-core calculation model: No IO writing
options.IO = 'no';                              % No input/output writing model (Default = 'no')
options.modout = 'yes';                         % Return simulations
options.ranking = 'C';                          % Example: Use Pareto ranking in C

%% Run the AMALGAM code and obtain non-dominated solution set
[X,F,output,Z,Y_sim] = AMALGAM(AMALGAMPar,Func_name,Par_info,options,func_in);