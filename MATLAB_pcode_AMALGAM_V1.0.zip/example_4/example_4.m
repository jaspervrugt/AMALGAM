% ----------------------------------------------------------------------------------------- %
%      AAA      MM       MM      AAA      LL        GGGGGGGGGGG      AAA      MM       MM   %
%     AA AA     MMM     MMM     AA AA     LL        GGG     GGG     AA AA     MMM     MMM   %
%     AA AA     MMMM   MMMM     AA AA     LL        GG       GG     AA AA     MMMM   MMMM   %
%    AA   AA    MM MM MM MM    AA   AA    LL        GGG     GGG    AA   AA    MM MM MM MM   %
%   AAAAAAAAA   MM  MMM  MM   AAAAAAAAA   LL        GGGGGGGGGGG   AAAAAAAAA   MM  MMM  MM   %
%   AA     AA   MM       MM   AA     AA   LL                 GG   AA     AA   MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL           GG  AA       AA  MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL  GGGGGGGGGGG  AA       AA  MM       MM   %
% ----------------------------------------------------------------------------------------- %

%% Define fields of AMALGAMPar
AMALGAMPar.N = 100;                             % Define population size
AMALGAMPar.T = 100;                             % How many generations?
AMALGAMPar.d = 10;                              % How many parameters?
AMALGAMPar.m = 2;                               % How many objective functions?

%% Define fields of Par_info
Par_info.initial = 'latin';                     % Latin hypercube sampling
Par_info.boundhandling = 'bound';               % Explicit boundary handling
Par_info.min = [0 -5*ones(1,AMALGAMPar.d-1)];   % If 'latin', min values
Par_info.max = [1  5*ones(1,AMALGAMPar.d-1)];   % If 'latin', max values

%% Define name of function
Func_name = 'AMALGAM_ZDT4';

%% Define func_in (additional input to "model" function)
func_in = AMALGAMPar.d; 

%% Now load Pareto front -- this is a benchmark problem
Fpar = load('ZDT4.txt');                        % Load Pareto solution set (known)         

%% Define structure options
options.ranking = 'C';                          % Use C script for ranking (faster)
options.print = 'no';                           % Print output to screen (tables and figures)

% Run the AMALGAM code and obtain non-dominated solution set
[X,F,output,Z] = AMALGAM(AMALGAMPar,Func_name,Par_info,options,func_in,Fpar);