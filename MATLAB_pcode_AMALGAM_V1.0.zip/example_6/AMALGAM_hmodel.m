function [ F , Y_sim ] = AMALGAM_hmodel ( x , func_in )
% hmodel - conceptual hydrologic model
% Reference: G. Schoups, and J.A. Vrugt, A formal likelihood function for parameter 
%   and predictive inference of hydrologic models with correlated, heteroscedastic, 
%   and non-Gaussian errors, Water Resources Research, 46, W10531, doi:10.1029/2009WR008933, 
%   2010.

% Extract various input data
[tout,data,hmodel_options,y0,Y_obs,n,id_d,N_d,id_nd,N_nd] = v2struct(func_in,func_in.fields);

y = hmodel(x,tout,data,hmodel_options,y0);              % Simulate discharge with x
Y = y(5,2:n+1) - y(5,1:n);                              % Compute discharge from state
Y_sim = Y(731:n);                                       % Remove first two years (burn-in)
F(1) = sqrt(sum((Y_sim(id_d)-Y_obs(id_d)).^2)/N_d);     % Calculate RMSE driven part
F(2) = sqrt(sum((Y_sim(id_nd)-Y_obs(id_nd)).^2)/N_nd);  % Calculate RMSE nondriven part