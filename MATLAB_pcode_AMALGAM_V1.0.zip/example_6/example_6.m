% ----------------------------------------------------------------------------------------- %
%      AAA      MM       MM      AAA      LL        GGGGGGGGGGG      AAA      MM       MM   %
%     AA AA     MMM     MMM     AA AA     LL        GGG     GGG     AA AA     MMM     MMM   %
%     AA AA     MMMM   MMMM     AA AA     LL        GG       GG     AA AA     MMMM   MMMM   %
%    AA   AA    MM MM MM MM    AA   AA    LL        GGG     GGG    AA   AA    MM MM MM MM   %
%   AAAAAAAAA   MM  MMM  MM   AAAAAAAAA   LL        GGGGGGGGGGG   AAAAAAAAA   MM  MMM  MM   %
%   AA     AA   MM       MM   AA     AA   LL                 GG   AA     AA   MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL           GG  AA       AA  MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL  GGGGGGGGGGG  AA       AA  MM       MM   %
% ----------------------------------------------------------------------------------------- %

%% Define fields of AMALGAMPar
AMALGAMPar.N = 100;                             % Define population size
AMALGAMPar.T = 150;                             % How many generations?
AMALGAMPar.d = 7;                               % How many parameters?
AMALGAMPar.m = 2;                               % How many objective functions?

%% Define fields of Par_info
Par_info.initial = 'latin';                     % Latin hypercube sampling
Par_info.boundhandling = 'reflect';             % Explicit boundary handling
Par_info.min = [1   10  0.1 0.1 -10 0.1 0.1];   % If 'latin', min values
Par_info.max = [10 1000 100 100  10 10  150];   % If 'latin', max values

%% Define name of function
Func_name = 'AMALGAM_hmodel';

%% Define data and setup to be used for multi-criteria model calibration 
mopex = load('03451500.dly');                        % Now load the mopex data
idx = find(mopex(:,1) > 1959 & mopex(:,1) < 1999);   % Select calibration set
n = size(mopex,1); tout = 0:n;                       % Number of observations and time
Y_obs = mopex(idx(1:n),6); Y_obs = Y_obs(731:n)';    % Measured discharge data (mm/day) 
data.P     = mopex(idx(1:n),4)';                     % Daily rainfall (mm/d)
data.Ep    = mopex(idx(1:n),5)';                     % Daily evaporation (mm/d)
data.aS    = 1e-6;                                   % Percolation coefficient
hmodel_options.InitialStep = 1;                      % Initial time-step (d)
hmodel_options.MaxStep     = 1;                      % Maximum time-step (d)
hmodel_options.MinStep     = 1e-6;                   % Minimum time-step (d)
hmodel_options.RelTol      = 1e-3;                   % Relative tolerance
hmodel_options.AbsTol      = 1e-3*ones(5,1);         % Absolute tolerances (mm)
hmodel_options.Order       = 2;                      % 2nd order method (Heun)
y0 = 1e-6*ones(5,1);                                 % Initial conditions
id_d = find(data.P(731:n)>0); N_d = numel(id_d);     % Index and total driven part
id_nd = find(data.P(731:n)==0); N_nd = numel(id_nd); % Index and total nondriven part
field_Names = {'fieldnames','tout','data','hmodel_options','y0','Y_obs','n','id_d',...
    'N_d','id_nd','N_nd'};                           % Create fields of func_in
func_in = v2struct(tout,data,hmodel_options,y0,Y_obs,n,id_d,N_d,id_nd,N_nd,...
    field_Names); func_in.fields = field_Names;      % Create func_in 

%% Define structure options
options.parallel = 'yes';                       % Multi-core calculation model: No IO writing
options.modout = 'yes';                         % Return simulations

%% Run the AMALGAM code and obtain non-dominated solution set
[X,F,output,Z,Y_sim] = AMALGAM(AMALGAMPar,Func_name,Par_info,options,func_in);