function Y = AMALGAM_ZDT6 ( x )
% ZDT6 - test function
% Reference: E. Zitzler, K. Deb, and L. Thiele, Comparison of multiobjective 
%   evolutionary algorithms: Empirical results, Evolutionary Computation, 8 (2), 
%   183-195, 2000

persistent d                    % Retain variables in local memory after first call

if isempty(d),                  % Only execute this part once
    d = size(x,1);              % Extract dimensionality of parameter space
end

f = 1 - exp(-4*x(1)) .* sin((6*pi*x(1))).^6;    % f
g = 1 + 9 * (1/(d-1) * sum(x(2:d))).^(1/4);     % g
h = 1 - (f./g).^2;                              % h
Y(1) = f; Y(2) = g.*h;                          % Return objective functions