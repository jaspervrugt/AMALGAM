function Y = AMALGAM_ZDT2 ( x , d )
% ZDT2 - test function
% Reference: E. Zitzler, K. Deb, and L. Thiele, Comparison of multiobjective 
%   evolutionary algorithms: Empirical results, Evolutionary Computation, 8 (2), 
%   183-195, 2000

f = x(1);                       % f
g = 1 + 9/(d-1)*sum(x(2:d));    % g
h = 1 - (f./g).^2;              % h
Y(1) = f; Y(2) = g.*h;          % Return objective functions