% ----------------------------------------------------------------------------------------- %
%      AAA      MM       MM      AAA      LL        GGGGGGGGGGG      AAA      MM       MM   %
%     AA AA     MMM     MMM     AA AA     LL        GGG     GGG     AA AA     MMM     MMM   %
%     AA AA     MMMM   MMMM     AA AA     LL        GG       GG     AA AA     MMMM   MMMM   %
%    AA   AA    MM MM MM MM    AA   AA    LL        GGG     GGG    AA   AA    MM MM MM MM   %
%   AAAAAAAAA   MM  MMM  MM   AAAAAAAAA   LL        GGGGGGGGGGG   AAAAAAAAA   MM  MMM  MM   %
%   AA     AA   MM       MM   AA     AA   LL                 GG   AA     AA   MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL           GG  AA       AA  MM       MM   %
%  AA       AA  MM       MM  AA       AA  LLLLLLLL  GGGGGGGGGGG  AA       AA  MM       MM   %
% ----------------------------------------------------------------------------------------- %

%% Define fields of AMALGAMPar
AMALGAMPar.N = 100;                         % Define population size
AMALGAMPar.T = 100;                         % How many generations?
AMALGAMPar.d = 30;                          % How many parameters?
AMALGAMPar.m = 2;                           % How many objective functions?

%% Define fields of Par_info
Par_info.initial = 'normal';                % Sampling from multivariate normal distribution
Par_info.mu = .5*ones(1,AMALGAMPar.d);      % Mean of this distribution
Par_info.cov = .2*eye(AMALGAMPar.d);        % Covariance of this distribution
Par_info.boundhandling = 'bound';           % Explicit boundary handling
Par_info.min = zeros(1,AMALGAMPar.d);       % If 'latin', min values
Par_info.max = ones(1,AMALGAMPar.d);        % If 'latin', max values

%% Define name of function (Zitzler et al., Evolutionary Computation, 8 (2), 183-195, 2000)
Func_name = 'AMALGAM_ZDT2';

%% Define func_in (additional input to "model" function)
func_in = AMALGAMPar.d; 

%% Now load Pareto front -- this is a benchmark problem
Fpar = load('ZDT2.txt');                    % Load Pareto solution set (known)         

%% Define structure options
options.print = 'yes';                      % Print output to screen (tables and figures)

%% Run the AMALGAM code and obtain non-dominated solution set
[X,F,output,Z] = AMALGAM (AMALGAMPar,Func_name,Par_info,options,func_in,Fpar);